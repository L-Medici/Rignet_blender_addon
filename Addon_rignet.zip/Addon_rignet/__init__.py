bl_info = {
    "name": "RigNet Addon",
    "author": "Mirko Simoni, Giulia Manoni and Lorenzo Medici",
    "version": (1, 0),
    "blender": (2, 93, 0),
    "location": "View3D > N",
    "description": "Addon using RigNet to load quick_start's model",
    "warning": "",
    "doc_url": "",
    "category": "",
}


import bpy
import os
from os import path
from random import randint
from bpy.types import (Panel, Operator)
from bpy.utils import register_class, unregister_class



def exec_rignet(model_id, bandwidth, threshold, context):
    """Run RigNet with Python on Anaconda environment"""
    scene = context.scene
    print('_________________________')
    os.system('python.exe --version')            
    os.chdir(scene.conf_path)
    if os.path.isfile('quick_start1.py'):
        os.system('python quick_start1.py '+model_id+' '+str(bandwidth)+' '+str(threshold))
        return True
    else: 
        return False
        
    
def import_obj(model_id, context):
    """Import remeshed object of model_id"""
    scene = context.scene
    file_loc1 = scene.conf_path+'quick_start\\'+model_id+'_remesh.obj'
    imported_object1 = bpy.ops.import_scene.obj(filepath=file_loc1)
    obj_object = bpy.context.selected_objects[0] 
    print('Imported file name: ', obj_object.name)
    
def create_bones(model_id, context):
    """Create bones from the relative file .txt origineted by RigNet"""
    scene = context.scene
    joint_pos = {}
    hiers = []
    rig_txt= scene.conf_path+"quick_start\\"+model_id+"_ori_rig.txt"
    txt = open(rig_txt,"r")
    lines = txt.readlines()
    bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
    bpy.ops.object.mode_set(mode='EDIT', toggle=False)        
    for line in lines:
        word = line.split() #split lines in word to extract joint's x-y-z positions
        if line.startswith("joints"):
            joint_pos[word[1]] = [float(word[2]),  float(word[3]), float(word[4])]
        if line.startswith("hier"): #hierarchy used to link neighbours bones position to each other
            hiers.append([word[1],word[2]])
            for joint in joint_pos:
                if word[1]==joint:
                    obArm = bpy.context.active_object #get the armature object
                    ebs = obArm.data.edit_bones
                    eb = ebs.new("Bone "+joint)                        
                    eb.head = joint_pos[joint] 
                if word[2]==joint:
                    eb.tail = joint_pos[joint]
    ob = bpy.context.object
    if ob.type == 'ARMATURE':
        armature = ob.data
    for bone in armature.edit_bones:
        if bone.name == "Bone":
            armature.edit_bones.remove(bone) #removal of unnecessary starting bone
    txt.close()
    
    """Adjusting and connection between armature and remeshed object"""
    bpy.ops.object.editmode_toggle() #switching from edit into object mode
    bpy.ops.transform.rotate(value=1.5708, orient_axis='X', orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(True, False, False), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False)
    modelname = ''+model_id+'_remesh' #name of the object displayed in the collection  
    bpy.data.objects["Armature"].select_set(True) #select armature
    bpy.data.objects[modelname].select_set(True) #select object
    bpy.ops.object.posemode_toggle() #switching from object into pose mode
    bpy.ops.object.parent_set(type='ARMATURE_AUTO') #linking of armature with object through automatic weights


class MyProperties(bpy.types.PropertyGroup): 
    """List of selectable models that can be tested with RigNet"""  
    my_enum : bpy.props.EnumProperty(
        name= "Model",
        description= "choose model_id",
        items= [('OP1', "Pigeon", ""),
                ('OP2', "Woman", ""),
                ('OP3', "Man", ""),
                ('OP4', "Girl", ""),
                ('OP5', "Machamp", ""),
                ('OP6', "Frillish", ""),
                ('OP7', "Girl2", ""),
                ('OP8', "Triceratops", ""),
                ('OP9', "Persian", ""),
                ('OP10', "Sandile", ""),
                ('OP11', "Rhyperior", ""),
                ('OP12', "Wailord", ""),
                ('OP13', "Flareon", ""),
                ('OP14', "Woobat", ""),
                ('OP15', "Muk", ""),
                ('OP16', "Beautifly", "")
        ]
    )

class ButtonOperator(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "random.1"
    bl_label = "Simple Random Operator"
    
    def execute(self, context):       
        scene = context.scene
        mytool = scene.my_tool
        
    
        """Assignment of model_id, bandwidth and threshold depending on selected model"""    
        if mytool.my_enum == 'OP1':
            model_id, bandwidth, threshold = "17872", 0.045, 0.75e-5
        if mytool.my_enum == 'OP2':
            model_id, bandwidth, threshold = "8210", 0.05, 1e-5
        if mytool.my_enum == 'OP3':
            model_id, bandwidth, threshold = "8330", 0.05, 0.8e-5
        if mytool.my_enum == 'OP4':
            model_id, bandwidth, threshold = "9477", 0.043, 2.5e-5
        if mytool.my_enum == 'OP5':
            model_id, bandwidth, threshold = "17364" , 0.058, 0.3e-5
        if mytool.my_enum == 'OP6':
            model_id, bandwidth, threshold = "15930", 0.055, 0.4e-5
        if mytool.my_enum == 'OP7':
            model_id, bandwidth, threshold = "8333", 0.04, 2e-5
        if mytool.my_enum == 'OP8':
            model_id, bandwidth, threshold = "8338", 0.052, 0.9e-5
        if mytool.my_enum == 'OP9':
            model_id, bandwidth, threshold = "3318", 0.03, 0.92e-5
        if mytool.my_enum == 'OP10':
            model_id, bandwidth, threshold = "15446", 0.032, 0.58e-5
        if mytool.my_enum == 'OP11':
            model_id, bandwidth, threshold = "1347", 0.062, 3e-5
        if mytool.my_enum == 'OP12':
            model_id, bandwidth, threshold = "11814", 0.06, 0.6e-5
        if mytool.my_enum == 'OP13':
            model_id, bandwidth, threshold = "2982", 0.045, 0.3e-5
        if mytool.my_enum == 'OP14':
            model_id, bandwidth, threshold = "2586", 0.05, 0.6e-5
        if mytool.my_enum == 'OP15':
            model_id, bandwidth, threshold = "8184", 0.05, 0.4e-5
        if mytool.my_enum == 'OP16':
            model_id, bandwidth, threshold = "9000", 0.035, 0.16e-5
        
        if exec_rignet(model_id, bandwidth, threshold, context): #run RigNet with previous parameters assigned
                        
            import_obj(model_id, context) #import of the object saved by RigNet
        
            create_bones(model_id, context) #create bones of the choosen model
        else:

            print('Please insert the right RigNet folder path!!')

        return {'FINISHED'}

      

class CustomPanel(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "RigNet Panel"
    bl_idname = "OBJECT_PT_random"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Rignet"

    def draw(self, context):
        """Initialization of object, scene and layout panel"""
        obj = context.object
        scene = context.scene
        mytool = scene.my_tool
        layout = self.layout        
        col = layout.column()
        col.prop(context.scene, 'conf_path')
        layout.prop(mytool, "my_enum")
        row = layout.row()
        row.operator(ButtonOperator.bl_idname, text="Run", icon='GROUP_BONE')
  
        
__classes__ = (ButtonOperator, CustomPanel, MyProperties)

def register():
    for __class__ in __classes__:
        register_class(__class__)
    bpy.types.Scene.my_tool = bpy.props.PointerProperty(type= MyProperties)
    bpy.types.Scene.conf_path = bpy.props.StringProperty \
      (
      name = "RigNet Path",
      default = "",
      description = "Define the path of RigNet folder",
      subtype = 'DIR_PATH'
      )

def unregister():
    for __class__ in __classes__:
        unregister_class(__class__)
    del bpy.types.Scene.my_tool
    del bpy.types.Scene.conf_path
    
if __name__ == "__main__":
    register()